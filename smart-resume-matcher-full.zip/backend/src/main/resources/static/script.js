document.getElementById('uploadForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fileInput = document.getElementById('file');
  const formData = new FormData();
  formData.append("file", fileInput.files[0]);

  const res = await fetch("/api/resume/upload", {
    method: "POST",
    body: formData
  });

  const text = await res.text();
  document.getElementById('result').innerText = text;
});
