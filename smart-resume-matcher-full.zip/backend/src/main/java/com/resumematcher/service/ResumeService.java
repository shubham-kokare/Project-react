package com.resumematcher.service;

import com.resumematcher.model.Job;
import com.resumematcher.repository.JobRepository;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.sax.BodyContentHandler;
import org.apache.tika.parser.ParseContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ResumeService {

    @Autowired
    private JobRepository jobRepo;

    public String parseAndMatchResume(MultipartFile file) {
        String content = parseFile(file);
        List<Job> allJobs = jobRepo.findAll();

        List<Job> matched = allJobs.stream()
            .filter(job -> Arrays.stream(job.getSkills().split(","))
                .anyMatch(skill -> content.toLowerCase().contains(skill.trim().toLowerCase())))
            .collect(Collectors.toList());

        return matched.isEmpty() ? "No match found" : matched.toString();
    }

    private String parseFile(MultipartFile file) {
        try (InputStream stream = file.getInputStream()) {
            AutoDetectParser parser = new AutoDetectParser();
            BodyContentHandler handler = new BodyContentHandler();
            parser.parse(stream, new Metadata(), handler, new ParseContext());
            return handler.toString();
        } catch (Exception e) {
            return "Failed to parse";
        }
    }
}
