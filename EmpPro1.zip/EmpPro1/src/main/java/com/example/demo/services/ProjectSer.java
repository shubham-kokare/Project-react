package com.example.demo.services;

import com.example.demo.entities.Project;

public interface ProjectSer {

	void savePData(Project p);

}
