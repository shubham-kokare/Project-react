package com.example.demo.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.*;
import javax.persistence.ManyToMany;

@Entity
public class Emp {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String nameString;
	
	@ManyToMany
	@JoinTable(
			   name = "Emp_Pro",
			   joinColumns = @JoinColumn(name = "e_id"),
			   inverseJoinColumns = @JoinColumn(name = "p_id")
			)
	private Set<Project> project = new HashSet<>();

	public Emp() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Emp(int id, String nameString, Set<Project> project) {
		super();
		this.id = id;
		this.nameString = nameString;
		this.project = project;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNameString() {
		return nameString;
	}

	public void setNameString(String nameString) {
		this.nameString = nameString;
	}

	public Set<Project> getProject() {
		return project;
	}

	public void setProject(Set<Project> project) {
		this.project = project;
	}

	@Override
	public String toString() {
		return "Emp [id=" + id + ", nameString=" + nameString + ", project=" + project + "]";
	}
	
}
