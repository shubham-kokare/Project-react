package com.example.demo.epcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Emp;
import com.example.demo.entities.Project;
import com.example.demo.services.EmpSer;
import com.example.demo.services.ProjectSer;

@RestController
public class PEController {
	
	@Autowired
	EmpSer eser;
	
	@Autowired
	ProjectSer pser;
	
	@PostMapping("/saveE")
	public String saveEmp(@RequestBody Emp e) {
		eser.saveEData(e);
		return "Emp saved";
	}
	
	@PostMapping("/saveP")
	public String saveProject(@RequestBody Project p) {
		pser.savePData(p);
		return "Project saved";
	}
	
	@PutMapping("/{eid}/project/{pid}")
	public String PEData(@PathVariable int eid,@PathVariable int pid) {
		eser.savePEData(eid,pid);
		return "Done";
	}

}
