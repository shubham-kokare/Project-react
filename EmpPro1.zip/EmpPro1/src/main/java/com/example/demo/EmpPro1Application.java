package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpPro1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmpPro1Application.class, args);
	}

}
