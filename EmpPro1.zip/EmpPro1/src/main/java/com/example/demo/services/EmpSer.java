package com.example.demo.services;

import com.example.demo.entities.Emp;

public interface EmpSer {

	void saveEData(Emp e);

	void savePEData(int eid, int pid);

}
