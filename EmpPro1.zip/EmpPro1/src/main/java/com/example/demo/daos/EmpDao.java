package com.example.demo.daos;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Emp;
import com.example.demo.entities.Project;
import com.example.demo.repos.Emprepo;
import com.example.demo.repos.Projectrepo;
import com.example.demo.services.EmpSer;

@Service
public class EmpDao implements EmpSer{

	@Autowired
	Emprepo erepo;
	
	@Autowired
	Projectrepo prepo;
	
	@Override
	public void saveEData(Emp e) {
		erepo.save(e);
	}

	@Override
	public void savePEData(int eid, int pid) {
		Set<Project> project = null;
		
		Emp e = erepo.findById(eid).get();
		Project p = prepo.findById(pid).get();
		
		project = e.getProject();
		project.add(p);
		
		e.setProject(project);
		erepo.save(e);
	}

}
