package com.example.demo.daos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Project;
import com.example.demo.repos.Projectrepo;
import com.example.demo.services.ProjectSer;

@Service
public class ProjectDao implements ProjectSer{

	@Autowired
	Projectrepo prepo;
	
	@Override
	public void savePData(Project p) {
		// TODO Auto-generated method stub
		prepo.save(p);
	}

}
